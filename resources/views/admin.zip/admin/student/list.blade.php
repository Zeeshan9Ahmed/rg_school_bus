@extends('admin.master')
@section('title')
<title>RG School Bus Students List</title>
@stop
@section('content')
              <div class="dt_main st">
                <div class="dash_tab_2 students">
                    <div class="sticky">
                      <div class="row align-items-center">
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                          <div class="parent">
                            <h4>Students Management</h4>
                          </div>
                        </div>                          
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                          <div class="search_filter">
                            <div class="row align-items-center">
                              <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4"></div>
                              <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                                <div class="fill_div">
                                  <a href="javascript:void(0)"><img src="{{asset('assets/images/fil.png')}}" class="img-fluid" alt=""> </a>
                                  <input type="text" placeholder="Search">
                                  <button type="button"><i class="fa-solid fa-magnifying-glass"></i></button>
                                </div>  
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
           
                  <div class="parent_table table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th class="text-left">Parents Name</th>
                          <th class="text-center">No of Child</th>
                          <th class="text-center">Driver Name</th>
                          <th class="text-center">Status</th>
                          <th class="text-right">Details</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><img src="{{asset('assets/images/tb_1.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_2.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_3.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_4.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_5.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_6.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_7.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_8.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_9.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_10.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>                            
                        <tr>
                          <td><img src="{{asset('assets/images/tb_11.png')}}" class="img-fluid" alt=""> <span>Michael David</span></td>
                          <td class="text-center">05</td>
                          <td class="text-center">John Driver</td>
                          <td class="text-center">Active</td>
                          <td class="text-right"><a href="{{route('student-details')}}">View Details</a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <!-- Modal -->
@stop