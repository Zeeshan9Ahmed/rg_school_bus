@extends('admin.master')
@section('title')
<title>RG School Bus Driver List</title>
@stop
@section('content')
        
            <div class="dt_main dr">
            <div class="dash_tab_2 drivers">
              <div class="sticky">
                <div class="row align-items-center">
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="parent">
                      <h4>Drivers Management</h4>
                    </div>
                  </div>                          
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="search_filter">
                      <div class="row align-items-center">
                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                          <div class="fill_div">
                            <a href="javascript:void(0)"><img src="{{asset('assets/images/fil.png')}}" class="img-fluid" alt=""> </a>
                            <input type="text" placeholder="Search">
                            <button type="button"><i class="fa-solid fa-magnifying-glass"></i></button>
                          </div>  
                        </div>
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                          <div class="view">
                            <a href="javascript::void(0)" class="btn btn_green" id="add-driver-btn"> Add new Driver</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
               </div>
              <div class="parent_table table-responsive">
                <table class="table">
                  <thead>
                    <tr>
                      <th class="text-left">Driver Name</th>
                      <th class="text-center">Bus No </th>
                      <th class="text-center">No of Child</th>
                      <!--<th class="text-center">No Of Parents</th>-->
                      <!-- <th class="text-center">Seating Capicity</th> -->
                      <!-- <th class="text-center">Status</th> -->
                      <th class="text-right">Details</th>
                    </tr>
                  </thead>
                  <tbody>
                            @forelse($records as $record)
                            <?php
                            if($record->driverchilds_count){
                                $status = 'Active';
                                $url = route('driver-details',['id'=>$record->UserID]);
                            }else{
                                $status = 'Deactive';
                                $url = "javascript::void(0)";
                            }
                            ?>
                                  <?php
                            if($record->ProfilePicture){
                                $img = $record->ProfilePicture;
                            }else{
                              $img = 'demo-profile.png';
                            }
                            ?>
                            <tr>
                                <td><img src="{{asset('upload/profile/'. $img )}}" class="img-fluid" alt=""> <span>{{$record->FirstName.' '.$record->LastName}}</span></td>
                                <td class="text-center">{{$record->bus->BusRegistrationNumber}}</td>
                                <td class="text-center">{{$record->driverchilds_count}}</td>
                                <!--<td class="text-center">{{$record->driverparents_count}}</td>-->
                                <!-- <td class="text-center">{{$status}}</td> -->
                                <td class="text-right"><a href={{$url}}>View Details</a></td>
                            </tr>
                            @empty
                            <tr>
                                <td class="text-center" colspan="5"> Records not found</td>
                            </tr>
                            @endforelse
                        </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- Modal -->
<div class="dash_modal">
  <div class="modal fade" id="exampleModal4" tabindex="-1" aria-labelledby="exampleModal4Label" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <div class="row">
            <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
              <h5 class="modal-title" id="exampleModal4Label">Notification</h5>
            </div>
            <div class="col-xs-12 col-sm-7 col-md-7 col-lg-7">
              <!-- <button type="" e="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
              <div class="togal_btn ">
                <p>Only show unread <input type="checkbox"></p>
              </div>
            </div>
          </div>
        </div>
        <div class="dash_body">
          <div class="modal-body">
            <p>Today</p>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

 <!-- add new driver  -->
 <div class="parent_detail success_modal">
      <div class="modal fade" id="add-driver-modal" aria-hidden="true" aria-labelledby="exampleModalToggleLabel222" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered dr">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalToggleLabel222">Add New Driver</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

            <form action="#" id="add-driver-process" method="POST">
              <div class="row">
                  <div class="form-group">
                    <input type="text" placeholder="First Name" id="FirstName" name="FirstName">
                  </div>
                  <div class="form-group">
                    <input type="text" placeholder="Last Name" id="LastName" name="LastName">
                  </div>
                  <div class="form-group">
                    <input type="email" placeholder="Email" id="Email" name="Email">
                  </div>
                  <div class="form-group">
                    <input type="tel" placeholder="Phone Number" id="PhoneNumber" name="PhoneNumber">
                  </div>
                  <div class="form-group">
                    <input type="number" placeholder="Seating Capacity" id="SeatingCapacity" name="SeatingCapacity">
                  </div>
                  <!--<div class="form-group" id="school-div-id">-->
                    
                  <!--</div>   -->
                  <div class="form-group" id="bus-div-id">
                    
                  </div>                  
                  <div class="form-group">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 centerCol">
                  <div class="text-center req">
                    <button type="submit" class="btn btn_green justify-content-center" style="margin: 0 auto 10px;float:inherit">Add Driver</button>
                    <!-- <a href="javascript:void(0)" class="btn btn_green">Add Driver</a> -->
                  </div>
                </div>
              </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
@stop

@section('footer-script')
<script>
  $(document).on('click', '#add-driver-btn', function() {
      
      //alert("okkkkk");return false;
     var id = $(this).data("id");
      $.ajax({
          url: "{{route('add-driver-data')}}",
          type: 'POST',
          data: {id},
          success: function(response) {
            $("#school-div-id").empty();
            var schoolList = '<select name="SchoolID" id="SchoolID">';
            schoolList += '<option value="">Please Select School</option>';
            let schools = response.schools;
            schools.forEach(function(item) {
              schoolList += '<option value="'+item.SchoolID+'">'+item.SchoolName+'</option>';
            });
            schoolList += '</select>';
           
            $("#bus-div-id").empty();
            var busList = '<select name="BusID" id="BusID">';
            busList += '<option value="">Please Select Bus</option>';
            let buses = response.buses;
            buses.forEach(function(item) {
              busList += '<option value="'+item.BusID+'">'+item.BusTitle+' ('+item.BusRegistrationNumber+')</option>';
            });
            busList += '</select>';
            $("#school-div-id").html(schoolList);
            $("#bus-div-id").html(busList);
            $("#add-driver-modal").modal('show');
            console.log(response);
          },
          error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus);
          }
      });
  });
$('form[id="add-driver-process"]').validate({
      rules: {
        FirstName: {
              required: true,
        },
        Email: {
            required: true,
        },
        BusID: {
            required: true,
        }
      },
      messages: {
        FirstName: {
            required: "<span style='color:red'>This field is required</span>",
        },
        Email: {
            required: "<span style='color:red'>This field is required</span>",
        },
        BusID: {
            required: "<span style='color:red'>This field is required</span>",
        }
      },
      submitHandler: function(form) {
        let FirstName = $("#FirstName").val();
        let LastName = $("#LastName").val();
        let Email = $("#Email").val();
        let PhoneNumber = $("#PhoneNumber").val();
        let SeatingCapacity = $("#SeatingCapacity").val();
        let SchoolID = $("#SchoolID").val();
        let BusID = $("#BusID").val();
        if(SchoolID == ''){
          swal("School",'Please select school', "error");
          return false;
        }
        if(BusID == ''){
          swal("Bus",'Please select bus', "error");
          return false;
        }
        $.ajax({
          url: "{{route('add-driver-process')}}",
          type: 'POST',
          data: {FirstName,LastName,Email,PhoneNumber,SeatingCapacity,SchoolID,BusID},
          success: function(response) {
            swal("Driver",response.msg, "success");
              setTimeout(function() {
                $('#add-driver-process').trigger("reset");
                $("#add-driver-modal").modal('hide');
                location.reload();
              }, 2000);
          },
          error: function(jqXHR, textStatus, errorThrown) {
            swal("Driver",'something went wrong', "error");
          }
        });
      }
  });
</script>
@stop