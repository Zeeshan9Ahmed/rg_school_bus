<aside class="sideMenu">
	<nav>
		<ul class="list-unstyled">
			<li>
				<a href="index.php" class="navItem">
					<span>
						<img src="{{asset('assets/images/nav-icon-1.png')}}" alt="img">
					</span>
					<span>Home</span>
				</a>
			</li>
			<li>
				<a href="redeem-history.php" class="navItem">
					<span>
						<img src="{{asset('assets/images/nav-icon-2.png')}}" alt="img">
					</span>
					<span>Redeem History</span>
				</a>
			</li>
			<li>
				<a href="faqs.php" class="navItem">
					<span>
						<img src="{{asset('assets/images/nav-icon-3.png')}}" alt="img">
					</span>
					<span>Faq's</span>
				</a>
			</li>
			<li>
				<a href="privacy-policy.php" class="navItem">
					<span>
						<img src="{{asset('assets/images/nav-icon-4.png')}}" alt="img">
					</span>
					<span>Privacy Policy</span>
				</a>
			</li>
			<li>
				<a href="terms-conditions.php" class="navItem">
					<span>
						<img src="{{asset('assets/images/nav-icon-5.png')}}" alt="img">
					</span>
					<span>Terms & Conditions</span>
				</a>
			</li>
			<li>
				<a href="#!" class="navItem logoutBtn">
					<span>
						<img src="{{asset('assets/images/logout-icon.png')}}" alt="img">
					</span>
					<span>Logout</span>
				</a>
			</li>
		</ul>
	</nav>
	<button class="sideCls xy-center"><i class="fa-solid fa-xmark"></i></button>
</aside>