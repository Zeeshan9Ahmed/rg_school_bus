@include('admin/include/header')
@include('admin/include/header-bar')
@yield('content')
@include('admin/include/footer')