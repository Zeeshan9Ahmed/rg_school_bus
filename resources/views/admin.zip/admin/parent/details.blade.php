@extends('admin.master')
@section('title')
<title>RG School Bus Parent Details</title>
@stop
@section('content')
        <div class="dash_tab ">
              <div class="dash_tab_2 req p_detail">
                <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="parent">
                      <h4>Parents Details</h4>
                    </div>
                  </div>                          
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                  </div>
                </div>
                <hr>                        
                <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="parent">
                      <?php
                      if($record->ProfilePicture){
                          $img = $record->ProfilePicture;
                      }else{
                        $img = 'demo-profile.png';
                      }
                      ?>
                      <h4><img src="{{asset('upload/profile/'.$img)}}" alt=""> {{$record->FirstName.' '.$record->LastName}} </h4>
                    </div>
                  </div>                          
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <!-- <div class="togal_btn ">
                      <p>Status: In-Active <input type="checkbox"></p>
                    </div> -->
                  </div>
                </div>
                <hr>
                <div class="parents_requaste">
                  <div class="row">
                   
                            @forelse($records as $rec)
                             <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                              <div class="req_box">
                                <div class="row">
                                  <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 pd0">
                                    <div class="child_text">
                                    <?php
                                      if($rec->ProfilePicture){
                                          $img = $rec->ProfilePicture;
                                      }else{
                                        $img = 'demo-profile.png';
                                      }
                                      ?>
                                      <h4><img src="{{asset('upload/profile/'.$img)}}" class="img-circle" alt=""> {{$rec->ChildName}} <a href="javascript:void(0)" data-id="{{$rec->ChildID}}" class="edit-child"><i class="fa-solid fa-pen-to-square"></i></a></h4>
                                      <span>Gender: {{$rec->Gender}}</span>
                                      <span>Age: {{$rec->Age}} Year</span>
                                      <?php
                                      if($rec->driver){
                                          $driver_FirstName = $rec->driver->FirstName;
                                          $driver_LastName = $rec->driver->LastName;
                                      }else{
                                        $driver_FirstName = '';
                                        $driver_LastName = '';
                                      }
                                      if($rec->school){
                                        $SchoolName = $rec->school->SchoolName;
                                      }else{
                                        $SchoolName = '';
                                      }
                                      if($rec->ShiftStartTime && $rec->ShiftEndTime){
                                        $ShiftTime = $rec->ShiftStartTime.' to '.$rec->ShiftEndTime;
                                      }else{
                                        $ShiftTime = '';
                                      }
                                      ?>
                                      <span>Driver: {{$driver_FirstName.' '.$driver_LastName}}</span>
                                    </div>  
                                  </div>
                                  <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 pd0">
                                    <div class="child_text class_text">
                                      <span>Class : {{$rec->Class}}</span>
                                      <span>Roll No: {{$rec->RollNumber}}</span>
                                      <span>School: {{$SchoolName}}</span>
                                      <span>Shift Time {{$ShiftTime}}</span>
                                    </div>
                                  </div>
                                  <!-- <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="atten"><a href="javascript:void(0)" data-bs-target="#calendarexampleModalToggle222" data-bs-toggle="modal">Attendance Record</a></div>
                                  </div> -->
                                </div>
                              </div>
                            </div> 
                            @empty
                            @endforelse
                                                  
                                                 
                                        
                  </div>
                </div>
              </div>
        </div>
      </div>
    </div>
  </div>
</div>
</section>

<!-- edit childs detail modal  -->
<div class="parent_detail success_modal">
  <div class="modal fade" id="childexampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel22" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalToggleLabel22">Edit Child Details</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <form action="#" id="update-child" method="POST">
              <div class="form-group">
                <input type="text" placeholder="Child Name" name="ChildName" id="ChildName">
              </div>
              <div class="form-group">
                <input type="text" placeholder="Class" name="Class" id="Class">
              </div>
              <div class="form-group">
                <input type="text" placeholder="Roll No" name="RollNumber" id="RollNumber">
              </div>
              <div class="form-group">
                <input type="number" placeholder="Age" name="Age" id="Age">
              </div> 
              <div class="form-group">
                <input type="time" class="form-control" placeholder="Shift Start Time" name="ShiftStartTime" id="ShiftStartTime">
              </div>   </br>               
              <div class="form-group">
                <input type="time" class="form-control"  placeholder="Shift End Time" name="ShiftEndTime" id="ShiftEndTime">
              </div></br>  
              <div class="form-group">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 centerCol" id="driver-list">
                  
                </div>
                <div class="justify-content-center req" align="center">
                  <input type="hidden" name="ChildID" id="ChildID" value="">
                  <button type="submit" class="btn btn_green justify-content-center">Update Child Profile</button>
                  <!-- <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal3" data-bs-dismiss="modal" class="btn btn_green">Update Child Profile </a> -->
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  <!-- success_modal -->
<div class="success_modal reset_password">
  <div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModal3Label" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModal3Label"> Successful</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="icon_box"><a href="javascript:void(0)"><i class="fa-solid fa-check"></i></a></div>
              <p>You have successfully reset your password</p>
              <div class="ss_form">
                 <a href="javascript:void(0)" class="green"   data-bs-dismiss="modal">  Continue</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- parent_detail -->
@stop
@section('footer-script')
<script>
  $(document).on('click', '.edit-child', function() {
      //alert("okkkkk");
     var id = $(this).data("id");
      $.ajax({
          url: "{{route('edit-child')}}",
          type: 'POST',
          data: {id},
          success: function(response) {
            let c = response.child;
            let d = response.drivers;
            //console.log(d);return false;
            $("#ChildName").val(c.ChildName);
            $("#Class").val(c.Class);
            $("#RollNumber").val(c.RollNumber);
            $("#Age").val(c.Age);
            $("#ShiftStartTime").val(c.ShiftStartTime);
            $("#ShiftEndTime").val(c.ShiftEndTime);
            $("#ChildID").val(c.ChildID);
            $("#driver-list").empty();
            var divsToAppend = '<select name="DriverID" id="DriverID">';
            divsToAppend += '<option value="">please select driver</option>';
            let diver_id = c.DriverID;
            d.forEach(function(item) {
              let s= '';
              if(diver_id == item.UserID ){
                s= 'selected';
              }
              divsToAppend += '<option '+s+' value="'+item.UserID +'">'+item.FirstName+' '+item.LastName+'</option>';
            });
            divsToAppend += '</select>';
            $("#driver-list").html(divsToAppend);
            $("#childexampleModalToggle2").modal('show');
            console.log(response);
          },
          error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus);
          }
      });
  });

$('form[id="update-child"]').validate({
      rules: {
        ChildName: {
              required: true,
        },
        Class: {
            required: true,
        },
        RollNumber: {
            required: true,
        }
      },
      messages: {
        ChildName: {
            required: "<span style='color:red'>This field is required</span>",
        },
        Class: {
            required: "<span style='color:red'>This field is required</span>",
        },
        RollNumber: {
            required: "<span style='color:red'>This field is required</span>",
        }
      },
      submitHandler: function(form) {
        let ChildName = $("#ChildName").val();
        let Class = $("#Class").val();
        let RollNumber = $("#RollNumber").val();
        let Age = $("#Age").val();
        let ShiftStartTime = $("#ShiftStartTime").val();
        let ShiftEndTime = $("#ShiftEndTime").val();
        let DriverID = $("#DriverID").val();
        let ChildID = $("#ChildID").val();
        if(DriverID == ''){
          swal("Driver",'Please select driver', "error");
          return false;
        }
        $.ajax({
          url: "{{route('update-child')}}",
          type: 'POST',
          data: {ChildID,ChildName,Class,RollNumber,Age,ShiftStartTime,ShiftEndTime,DriverID},
          success: function(response) {
           
            if(response.error){
              swal("Child",response.msg, "error");
            }else{
              $("#childexampleModalToggle2").modal('hide');
              swal("Child",response.msg, "success");
              setTimeout(function() {
                $('#update-child').trigger("reset");
                location.reload();
              }, 2000);
              
            }
          },
          error: function(jqXHR, textStatus, errorThrown) {
             swal("Child","Something Went Wrong", "error");
          }
        });
      }
  });
</script>
@stop