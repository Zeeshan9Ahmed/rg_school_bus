@extends('admin.master')
@section('title')
<title>RG School Bus Parent Requests</title>
@stop
@section('content')
                <div class="dash_tab">
                    <div class="dash_tab_2 req ">
                      <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                          <div class="parent">
                            <h4>Parents Requests</h4>
                          </div>
                        </div>                          
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                        </div>
                      </div>
                      <hr>
                      <div class="parents_requaste v">
                        <div class="row">
                        @forelse($records as $rec)
                          <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                            <div class="req_box">

                              <div class="row">
                                <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                                  <div class=""> 
                                  <?php
                                    if($rec->parent->ProfilePicture){
                                        $img =$rec->parent->ProfilePicture;
                                    }else{
                                      $img = 'demo-profile.png';
                                    }
                                    ?>
                                    <h3><img src="{{asset('upload/profile/'.$img)}}" class="img-fluid" alt=""> {{$rec->parent->FirstName.' '.$rec->parent->LastName}}</h3>
                                  </div>
                                </div>
                                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                  <div class="cross">
                                    <ul>
                                      <li><a href="javascript:void(0)" data-id="{{$rec->ChildID}}" class="disaaproved-request"><i class="fa-solid fa-x"></i></a></li>
                                      <li><a href="javascript:void(0)"  data-id="{{$rec->ChildID}}" class="approved-request"><i class="fa-solid fa-check"></i></a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                  <div class="child_text">
                                   <?php
                                    if($rec->ProfilePicture){
                                        $img =$rec->ProfilePicture;
                                    }else{
                                      $img = 'demo-profile.png';
                                    }
                                    ?>
                                    <h4><img src="{{asset('upload/profile/'.$img)}}" class="img-fluid" alt=""> {{$rec->ChildName}}</h4>
                                    <span>Gender: {{$rec->Gender}}</span>
                                    <span>Age: {{$rec->Age}} Year</span>
                                  </div>  
                                </div>
                                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                  <div class="child_text class_text">
                                    <span>Class {{$rec->Class}}</span>
                                    <span>Roll No {{$rec->RollNumber}}</span>
                                    <?php
                                    if($rec->school){
                                      $SchoolName = $rec->school->SchoolName;
                                    }else{
                                      $SchoolName = '';
                                    }
                                    ?>
                                    <span>{{$SchoolName}}</span>
                                  </div>
                                </div>
                              </div>

                            </div>
                          </div>
                          @empty
                          @endforelse
                        </div>
                      </div>
                    </div>
                </div>
                </div>
              </div>
            </div>
          </div>
      </section>
    </div>

    <!-- Modal -->
@stop
@section('footer-script')
<script>
  $(document).on('click', '.disaaproved-request', function() {
     var ChildID = $(this).data("id");
     swal({
            title: "Are you sure?",
            text: "You want to cancel request!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Yes, I am sure!',
            cancelButtonText: "No, cancel it!",
            closeOnConfirm: false,
            closeOnCancel: true
         },
        function(isConfirm){

          if (isConfirm){
            $.ajax({
              url: "{{route('disapproved-request')}}",
              type: 'POST',
              data: {ChildID},
              success: function(response) {
                swal("Request!",response.msg, "success");
                setTimeout(function() {
                  location.reload();
                }, 2000);
                
              },
              error: function(jqXHR, textStatus, errorThrown) {
                swal("Error", "Something went wrong :)", "error");
              }
            });
          }
        });
  });

  $(document).on('click', '.approved-request', function() {
     var ChildID = $(this).data("id");
     swal({
            title: "Are you sure?",
            text: "You want to approved request!",
            type: "success",
            showCancelButton: true,
            confirmButtonColor: '#6610f2',
            confirmButtonText: 'Yes, I am sure!',
            cancelButtonText: "No, cancel it!",
            closeOnConfirm: false,
            closeOnCancel: true
         },
        function(isConfirm){

          if (isConfirm){
            $.ajax({
              url: "{{route('get-drivers-list')}}",
              type: 'POST',
              data: {ChildID},
              success: function(response) {
                let d = response.records;
                $("#drivers-list-div-id").empty();
                var divsToAppend = '<select name="DriverID" id="DriverID">';
                divsToAppend += '<option value="">please select driver</option>';
                d.forEach(function(item) {
                  divsToAppend += '<option value="'+item.UserID +'">'+item.FirstName+' '+item.LastName+'</option>';
                });
                divsToAppend += '</select>';
                $("#drivers-list-div-id").html(divsToAppend);
                $('#u-id').val(ChildID);
                swal.close();
                $("#view-driver-modal").modal('show');
              },
              error: function(jqXHR, textStatus, errorThrown) {
                swal("Error", "Something went wrong :)", "error");
              }
            });
          }
        });
  });

  $(document).on('click', '.assigned-driver', function() {
     var ChildID = $('#u-id').val();
     var DriverID = $('#DriverID').val();
     if(DriverID == ''){
       swal("Driver",'Please select driver', "error");
       return false;
     }
      $.ajax({
        url: "{{route('approved-request')}}",
        type: 'POST',
        data: {ChildID,DriverID},
        success: function(response) {
          $("#view-driver-modal").modal('hide');
          swal("Request!",response.msg, "success");
          setTimeout(function() {
            location.reload();
          }, 2000);
        },
        error: function(jqXHR, textStatus, errorThrown) {
          swal("Error", "Something went wrong :)", "error");
        }
      });
  });

</script>
@stop