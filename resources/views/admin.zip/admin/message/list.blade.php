@extends('admin.master')
@section('title')
<title>RG School Bus Messages List</title>
@stop
@section('content')
              <div class="dash_tab_2 dash_tab_5">
                <div class="row align-items-center">
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="parent">
                      <h4>Group Messages</h4>
                    </div>
                  </div>                          
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                    <div class="chat_left_tabs">
                      <div class="fill_div">
                        <input type="text" placeholder="Search">
                        <button type="button"><i class="fa-solid fa-magnifying-glass"></i></button>
                      </div>
                       <ul class="nav nav-tabs" id="myTab" role="tablist">
                          <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="home-tab_chat" data-bs-toggle="tab" data-bs-target="#home_chat" type="button" role="tab" aria-controls="home_chat" aria-selected="true">
                              <span>12 min</span>
                              <img src="{{asset('assets/images/tb_1.png')}}" class="img-fluid" alt="">
                              <h4>ABC School</h4>
                              <p>Lorem ipsum dolor sit neque sit sec...</p>
                            </a>
                          </li>
                          <li class="nav-item" role="presentation">
                            <a class="nav-link" id="profile-tab_chat" data-bs-toggle="tab" data-bs-target="#profile_chat" type="button" role="tab" aria-controls="profile_chat" aria-selected="false">
                              <span>12 min</span>
                              <img src="{{asset('assets/images/tb_1.png')}}" class="img-fluid" alt="">
                              <h4>ABC School</h4>
                              <p>Lorem ipsum dolor sit neque sit sec...</p>
                            </a>
                          </li>
                          <li class="nav-item" role="presentation">
                            <a class="nav-link" id="contact-tab_chat" data-bs-toggle="tab" data-bs-target="#contact_chat" type="button" role="tab" aria-controls="contact_chat" aria-selected="false">
                              <span>12 min</span>
                              <img src="{{asset('assets/images/tb_1.png')}}" class="img-fluid" alt="">
                              <h4>ABC School</h4>
                              <p>Lorem ipsum dolor sit neque sit sec...</p>
                            </a>
                          </li>  
                          <li class="nav-item" role="presentation">
                            <a class="nav-link " id="home-tab_chat_2" data-bs-toggle="tab" data-bs-target="#home_chat_2" type="button" role="tab" aria-controls="home_chat_2" aria-selected="true">
                              <span>12 min</span>
                              <img src="{{asset('assets/images/tb_1.png')}}" class="img-fluid" alt="">
                              <h4>ABC School</h4>
                              <p>Lorem ipsum dolor sit neque sit sec...</p>
                            </a>
                          </li>
                          <li class="nav-item" role="presentation">
                            <a class="nav-link" id="profile-tab_chat_2" data-bs-toggle="tab" data-bs-target="#profile_chat_2" type="button" role="tab" aria-controls="profile_chat_2" aria-selected="false">
                              <span>12 min</span>
                              <img src="{{asset('assets/images/tb_1.png')}}" class="img-fluid" alt="">
                              <h4>ABC School</h4>
                              <p>Lorem ipsum dolor sit neque sit sec...</p>
                            </a>
                          </li>
                          <li class="nav-item" role="presentation">
                            <a class="nav-link" id="contact-tab_chat_2" data-bs-toggle="tab" data-bs-target="#contact_chat_2" type="button" role="tab" aria-controls="contact_chat_2" aria-selected="false">
                              <span>12 min</span>
                              <img src="{{asset('assets/images/tb_1.png')}}" class="img-fluid" alt="">
                              <h4>ABC School</h4>
                              <p>Lorem ipsum dolor sit neque sit sec...</p>
                            </a>
                          </li>  
                          <li class="nav-item" role="presentation">
                            <a class="nav-link" id="contact-tab_chat_3" data-bs-toggle="tab" data-bs-target="#contact_chat_3" type="button" role="tab" aria-controls="contact_chat_3" aria-selected="false">
                              <span>12 min</span>
                              <img src="{{asset('assets/images/tb_1.png')}}" class="img-fluid" alt="">
                              <h4>ABC School</h4>
                              <p>Lorem ipsum dolor sit neque sit sec...</p>
                            </a>
                          </li>
                      </ul>
                    </div>  
                  </div>
                  <div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
                    <div class="chat_right_tabs">
                      <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home_chat" role="tabpanel" aria-labelledby="home-tab_chat">
                          <div class="textarea_main">
                            <div class="chat_right_main">
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <h3> <img src="{{asset('assets/images/sc.png')}}" class="img-fluid" alt="">ABC School</h3>
                                  <hr>  
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_1.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>                                        
                                  <div class="chat_1 chat_2">
                                    <img src="{{asset('assets/images/abc.png')}}" class="img-fluid" alt="">
                                    <h4>Abc School</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <div class="clearfix"></div>
                                    <span>12 min</span>
                                  </div>
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_2.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="row">
                                <div class="chat_input">
                                   <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 centerCol">
                                    <div class="form-group">
                                      <input type="text" placeholder="Your message here...!" >
                                      <button><i class="fas fa-paper-plane"></i></button>
                                    </div>
                                  </div> 
                                </div>
                            </div>
                          </div>
                        </div>
                        <div class="tab-pane fade" id="profile_chat" role="tabpanel" aria-labelledby="profile-tab_chat">
                          <div class="textarea_main">
                            <div class="chat_right_main">
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <h3> <img src="{{asset('assets/images/sc.png')}}" class="img-fluid" alt="">ABC School</h3>
                                  <hr>  
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_1.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>                                        
                                  <div class="chat_1 chat_2">
                                    <img src="{{asset('assets/images/abc.png')}}" class="img-fluid" alt="">
                                    <h4>Abc School</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <div class="clearfix"></div>
                                    <span>12 min</span>
                                  </div>
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_2.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="row">
                                <div class="chat_input">
                                   <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 centerCol">
                                    <div class="form-group">
                                      <input type="text" placeholder="Your message here...!" >
                                      <button><i class="fas fa-paper-plane"></i></button>
                                    </div>
                                  </div> 
                                </div>
                            </div>
                          </div>
                        </div>
                        <div class="tab-pane fade" id="contact_chat" role="tabpanel" aria-labelledby="contact-tab_chat">
                          <div class="textarea_main">
                            <div class="chat_right_main">
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <h3> <img src="{{asset('assets/images/sc.png')}}" class="img-fluid" alt="">ABC School</h3>
                                  <hr>  
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_1.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>                                        
                                  <div class="chat_1 chat_2">
                                    <img src="{{asset('assets/images/abc.png')}}" class="img-fluid" alt="">
                                    <h4>Abc School</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <div class="clearfix"></div>
                                    <span>12 min</span>
                                  </div>
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_2.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="row">
                                <div class="chat_input">
                                   <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 centerCol">
                                    <div class="form-group">
                                      <input type="text" placeholder="Your message here...!" >
                                      <button><i class="fas fa-paper-plane"></i></button>
                                    </div>
                                  </div> 
                                </div>
                            </div>
                          </div>
                        </div>  
                        <div class="tab-pane fade" id="home_chat_2" role="tabpanel" aria-labelledby="home-tab_chat_2">
                          <div class="textarea_main">
                            <div class="chat_right_main">
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <h3> <img src="{{asset('assets/images/sc.png')}}" class="img-fluid" alt="">ABC School</h3>
                                  <hr>  
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_1.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>                                        
                                  <div class="chat_1 chat_2">
                                    <img src="{{asset('assets/images/abc.png')}}" class="img-fluid" alt="">
                                    <h4>Abc School</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <div class="clearfix"></div>
                                    <span>12 min</span>
                                  </div>
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_2.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="row">
                                <div class="chat_input">
                                   <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 centerCol">
                                    <div class="form-group">
                                      <input type="text" placeholder="Your message here...!" >
                                      <button><i class="fas fa-paper-plane"></i></button>
                                    </div>
                                  </div> 
                                </div>
                            </div>
                          </div>
                        </div>
                        <div class="tab-pane fade" id="profile_chat_2" role="tabpanel" aria-labelledby="profile-tab_chat_2">
                          <div class="textarea_main">
                            <div class="chat_right_main">
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <h3> <img src="{{asset('assets/images/sc.png')}}" class="img-fluid" alt="">ABC School</h3>
                                  <hr>  
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_1.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>                                        
                                  <div class="chat_1 chat_2">
                                    <img src="{{asset('assets/images/abc.png')}}" class="img-fluid" alt="">
                                    <h4>Abc School</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <div class="clearfix"></div>
                                    <span>12 min</span>
                                  </div>
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_2.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="row">
                                <div class="chat_input">
                                   <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 centerCol">
                                    <div class="form-group">
                                      <input type="text" placeholder="Your message here...!" >
                                      <button><i class="fas fa-paper-plane"></i></button>
                                    </div>
                                  </div> 
                                </div>
                            </div>
                          </div>
                        </div>
                        <div class="tab-pane fade" id="contact_chat_2" role="tabpanel" aria-labelledby="contact-tab_chat_2">
                          <div class="textarea_main">
                            <div class="chat_right_main">
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <h3> <img src="{{asset('assets/images/sc.png')}}" class="img-fluid" alt="">ABC School</h3>
                                  <hr>  
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_1.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>                                        
                                  <div class="chat_1 chat_2">
                                    <img src="{{asset('assets/images/abc.png')}}" class="img-fluid" alt="">
                                    <h4>Abc School</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <div class="clearfix"></div>
                                    <span>12 min</span>
                                  </div>
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_2.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="row">
                                <div class="chat_input">
                                   <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 centerCol">
                                    <div class="form-group">
                                      <input type="text" placeholder="Your message here...!" >
                                      <button><i class="fas fa-paper-plane"></i></button>
                                    </div>
                                  </div> 
                                </div>
                            </div>
                          </div>
                        </div>
                        <div class="tab-pane fade" id="contact_chat_3" role="tabpanel" aria-labelledby="contact-tab_chat_3">
                          <div class="textarea_main">
                            <div class="chat_right_main">
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <h3> <img src="{{asset('assets/images/sc.png')}}" class="img-fluid" alt="">ABC School</h3>
                                  <hr>  
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_1.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>                                        
                                  <div class="chat_1 chat_2">
                                    <img src="{{asset('assets/images/abc.png')}}" class="img-fluid" alt="">
                                    <h4>Abc School</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <div class="clearfix"></div>
                                    <span>12 min</span>
                                  </div>
                                  <div class="chat_1">
                                    <img src="{{asset('assets/images/ch_2.png')}}" class="img-fluid" alt="">
                                    <h4>John Smith</h4>
                                    <p>Lorem ipsum dolor sit amet sec...</p>
                                    <span>12 min</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="row">
                                <div class="chat_input">
                                   <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10 centerCol">
                                    <div class="form-group">
                                      <input type="text" placeholder="Your message here...!" >
                                      <button><i class="fas fa-paper-plane"></i></button>
                                    </div>
                                  </div> 
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- Modal -->
<div class="dash_modal">
  <div class="modal fade" id="exampleModal4" tabindex="-1" aria-labelledby="exampleModal4Label" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <div class="row">
            <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
              <h5 class="modal-title" id="exampleModal4Label">Notification</h5>
            </div>
            <div class="col-xs-12 col-sm-7 col-md-7 col-lg-7">
              <!-- <button type="" e="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
              <div class="togal_btn ">
                <p>Only show unread <input type="checkbox"></p>
              </div>
            </div>
          </div>
        </div>
        <div class="dash_body">
          <div class="modal-body">
            <p>Today</p>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
            <div class="dash_text">
              <h4>Lorem ipsum dolor sit amet</h4>
              <span>02:15AM</span>
              <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod tempor incididunt ut.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Button trigger modal -->
<div class="success_modal assign">
  <div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalToggleLabel">Assign Children to Another Driver</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="child_box all">
                <ul>
                  <li>
                    <label class="containerd"> Slect All
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
              <div class="child_box">
                <ul>
                  <li><img src="{{asset('assets/images/ch.jpg')}}" class="img-fluid" alt=""></li>
                  <li>Child Name</li>
                  <li>
                    <label class="containerd">
                    <input type="checkbox" >
                    <span class="checkmark"></span>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 centerCol">
              <div><a href="javascript:void(0)" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal" data-bs-dismiss="modal" class="btn btn_green">Assign To </a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- slect modal  -->
@stop